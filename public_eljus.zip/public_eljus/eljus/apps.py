from django.apps import AppConfig


class EljusConfig(AppConfig):
    name = 'eljus'
